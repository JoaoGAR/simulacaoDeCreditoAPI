$(document).ready(function () {

    const url = "http://localhost/api/v1/simulacao/oferta/melhorOpcao";

    $.ajax({
        url: url,
        method: 'POST',
        data: {'cpf': '111.111.111-11'},
        success: function (data) {
            data = $.map(data, function(el) { return el });
            console.log(data);
            $('#dataTable').DataTable({
                data: data,
                columns: [
                    { data: 'qtdParcelasMin' },
                    { data: 'qtdParcelasMax' },
                    { data: 'valorMin' },
                    { data: 'valorMax' },
                    { data: 'jurosMes' },
                    { data: 'valorFinalMin' },
                    { data: 'valorFinalMax' }
                ]
            });
        },
        error: function (error) {
            console.log("Erro ao buscar dados: ", error);
        }
    });
});